import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-[#0b1120] text-slate-400 py-12 px-6 border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 pb-8">
        
        {/* Brand Section */}
        <div className="md:col-span-6 space-y-3">
          <div className="flex items-center gap-2 text-white font-extrabold text-xl tracking-tight">
            <span className="text-[#4f46e5]">📖</span>
            <span>Skill Swap</span>
          </div>
          <p className="text-xs text-slate-400 max-w-sm leading-relaxed font-medium">
            Connecting students worldwide through peer-to-peer learning. 
            Share your skills, discover new passions, and grow together.
          </p>
        </div>

        {/* Platform Section */}
        <div className="md:col-span-3 space-y-3">
          <h4 className="text-xs font-extrabold uppercase tracking-wider text-white">
            Platform
          </h4>
          <ul className="space-y-2 text-xs font-semibold">
            <li>
              <Link to="/explore" className="hover:text-white transition-colors">
                Browse Lessons
              </Link>
            </li>
            <li>
              <Link to="/about" className="hover:text-white transition-colors">
                About Us
              </Link>
            </li>
            <li>
              <Link to="/signup" className="hover:text-white transition-colors">
                Join Community
              </Link>
            </li>
          </ul>
        </div>

        {/* Support Section */}
        <div className="md:col-span-3 space-y-3">
          <h4 className="text-xs font-extrabold uppercase tracking-wider text-white">
            Support
          </h4>
          <ul className="space-y-2 text-xs font-semibold">
            <li>
              <Link to="/contact" className="hover:text-white transition-colors">
                Contact Us
              </Link>
            </li>
            <li>
              <Link to="/terms" className="hover:text-white transition-colors">
                Terms & Conditions
              </Link>
            </li>
          </ul>
        </div>

      </div>

      {/* Footer Bottom */}
      <div className="max-w-7xl mx-auto pt-6 border-t border-slate-800/60 text-center text-[11px] text-slate-500 font-medium">
        © 2026 Skill Swap. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;