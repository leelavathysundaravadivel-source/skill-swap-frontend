import React, { useState, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AppContext } from '../context/AppContext';
import { BsEyeFill, BsEyeSlashFill } from 'react-icons/bs';

const Signup = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    offerSkill: '',
    seekSkill: ''
  });

  // BOTH PASSWORD FIELDS HIDDEN BY DEFAULT (false)
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [errorMessage, setErrorMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const { register } = useContext(AppContext);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (errorMessage) setErrorMessage('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    if (formData.password.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }

    setLoading(true);
    try {
      if (register) {
        await register(formData);
        navigate('/explore');
      }
    } catch (err) {
      setErrorMessage(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto px-6 py-12">
      <div className="bg-white border border-slate-200/80 rounded-3xl p-8 shadow-xs space-y-6">
        <div className="text-center space-y-1">
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Create your Account</h1>
          <p className="text-xs text-slate-500 font-medium">Join SkillSwap and exchange expertise with peers.</p>
        </div>

        {errorMessage && (
          <div className="bg-red-50 border border-red-200 text-red-600 text-xs p-3 rounded-xl font-bold">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold text-slate-700">
          <div>
            <label className="block mb-1 text-slate-800 font-bold">Full Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="John Doe"
              className="w-full px-4 py-3 border border-slate-200 rounded-xl font-normal focus:outline-none focus:border-[#4f46e5]"
              required
            />
          </div>

          <div>
            <label className="block mb-1 text-slate-800 font-bold">Email address</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="you@example.com"
              className="w-full px-4 py-3 border border-slate-200 rounded-xl font-normal focus:outline-none focus:border-[#4f46e5]"
              required
            />
          </div>

          {/* PASSWORD FIELD */}
          <div>
            <label className="block mb-1 text-slate-800 font-bold">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Strong password (6+ characters)"
                className="w-full px-4 py-3 pr-11 border border-slate-200 rounded-xl font-normal focus:outline-none focus:border-[#4f46e5]"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition cursor-pointer"
                title={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? (
                  <BsEyeFill className="text-base text-[#4f46e5]" />
                ) : (
                  <BsEyeSlashFill className="text-base text-slate-400" />
                )}
              </button>
            </div>
          </div>

          {/* CONFIRM PASSWORD FIELD */}
          <div>
            <label className="block mb-1 text-slate-800 font-bold">Confirm Password</label>
            <div className="relative">
              <input
                type={showConfirmPassword ? 'text' : 'password'}
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                placeholder="Re-enter your password"
                className="w-full px-4 py-3 pr-11 border border-slate-200 rounded-xl font-normal focus:outline-none focus:border-[#4f46e5]"
                required
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition cursor-pointer"
                title={showConfirmPassword ? "Hide password" : "Show password"}
              >
                {showConfirmPassword ? (
                  <BsEyeFill className="text-base text-[#4f46e5]" />
                ) : (
                  <BsEyeSlashFill className="text-base text-slate-400" />
                )}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block mb-1 text-slate-800 font-bold">Skills You Offer</label>
              <input
                type="text"
                name="offerSkill"
                value={formData.offerSkill}
                onChange={handleChange}
                placeholder="e.g. Java 21"
                className="w-full px-4 py-3 border border-slate-200 rounded-xl font-normal focus:outline-none focus:border-[#4f46e5]"
              />
            </div>
            <div>
              <label className="block mb-1 text-slate-800 font-bold">Skills You Seek</label>
              <input
                type="text"
                name="seekSkill"
                value={formData.seekSkill}
                onChange={handleChange}
                placeholder="e.g. AWS Cloud"
                className="w-full px-4 py-3 border border-slate-200 rounded-xl font-normal focus:outline-none focus:border-[#4f46e5]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#4f46e5] hover:bg-[#4338ca] text-white font-bold py-3.5 rounded-xl transition cursor-pointer shadow-md shadow-indigo-500/20 disabled:opacity-50 mt-2"
          >
            {loading ? 'Creating Account...' : 'Sign Up'}
          </button>
        </form>

        <div className="text-center pt-2 border-t border-slate-100 text-xs font-semibold text-slate-500">
          Already have an account?{' '}
          <Link to="/login" className="text-[#4f46e5] font-bold hover:underline">
            Log In
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Signup;