import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="max-w-7xl mx-auto px-6 py-16 space-y-20">
      
      {/* Hero Section */}
      <div className="flex flex-col items-center text-center space-y-6 max-w-4xl mx-auto">
        <span className="bg-indigo-50 border border-indigo-100 text-[#4f46e5] text-xs font-extrabold uppercase px-4 py-1.5 rounded-full tracking-wider shadow-2xs">
          ⚡ Peer-to-Peer Technical Knowledge Exchange
        </span>

        <h1 className="text-4xl sm:text-6xl font-black text-slate-900 tracking-tight leading-tight">
          Swap Coding Skills.<br />
          <span className="text-[#4f46e5]">Level Up Together.</span>
        </h1>

        <p className="text-slate-600 text-sm sm:text-base font-medium max-w-2xl leading-relaxed">
          Connect directly with fellow software engineers to exchange hands-on knowledge. 
          Teach what you master, learn what you seek—no subscriptions or course fees.
        </p>

        {/* Call to Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 pt-4 w-full sm:w-auto">
          <Link
            to="/explore"
            className="bg-[#4f46e5] hover:bg-[#4338ca] text-white font-extrabold px-8 py-4 rounded-2xl text-xs transition-all shadow-lg shadow-indigo-500/20 text-center"
          >
             Browse Skill Catalog
          </Link>
          <Link
            to="/signup"
            className="bg-white hover:bg-slate-50 border border-slate-200/90 text-slate-800 font-extrabold px-8 py-4 rounded-2xl text-xs transition-all shadow-2xs text-center"
          >
             Join Community
          </Link>
        </div>
      </div>

      {/* Feature Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white border border-slate-200/80 rounded-3xl p-8 shadow-xs space-y-3 hover:shadow-md transition-all">
          <div className="w-12 h-12 bg-indigo-50 text-[#4f46e5] rounded-2xl flex items-center justify-center text-xl font-bold">
            💻
          </div>
          <h3 className="text-lg font-bold text-slate-900">Modern Tech Stack</h3>
          <p className="text-xs text-slate-500 leading-relaxed font-medium">
            Learn high-demand technical skills like Java 21, Spring Boot, React, GCP, Python, and Microservices architecture.
          </p>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-3xl p-8 shadow-xs space-y-3 hover:shadow-md transition-all">
          <div className="w-12 h-12 bg-indigo-50 text-[#4f46e5] rounded-2xl flex items-center justify-center text-xl font-bold">
            🎯
          </div>
          <h3 className="text-lg font-bold text-slate-900">Synergy Score Match</h3>
          <p className="text-xs text-slate-500 leading-relaxed font-medium">
Our real-time engine automatically calculates mutual skill compatibility (0%, 50%, or 100%) for seamless exchanges.          </p>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-3xl p-8 shadow-xs space-y-3 hover:shadow-md transition-all">
          <div className="w-12 h-12 bg-indigo-50 text-[#4f46e5] rounded-2xl flex items-center justify-center text-xl font-bold">
            🎙️
          </div>
          <h3 className="text-lg font-bold text-slate-900">Smart Voice Search</h3>
          <p className="text-xs text-slate-500 leading-relaxed font-medium">
            Use AI-powered keyword voice search to instantly locate topics across the entire community catalog hands-free.
          </p>
        </div>
      </div>

    </div>
  );
};

export default Home;