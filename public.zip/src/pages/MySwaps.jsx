import React, { useState, useContext, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AppContext, isUserInbound, isUserOutbound } from '../context/AppContext';

const MySwaps = () => {
  const { user, proposals, fetchProposals } = useContext(AppContext);
  const [activeTab, setActiveTab] = useState('inbound'); // 'inbound' | 'outbound'
  const [loadingId, setLoadingId] = useState(null);

  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    fetchProposals();
  }, []);

  // Filter proposals for regular peer learners
  const inboundProposals = proposals.filter((p) => isUserInbound(p, user));
  const outboundProposals = proposals.filter((p) => isUserOutbound(p, user));

  // Handler to Accept or Decline Incoming Swaps
  const handleStatusUpdate = async (proposalId, newStatus) => {
    setLoadingId(proposalId);
    try {
      const token = localStorage.getItem('skillswap_token');
      const res = await fetch(`http://localhost:5000/api/swaps/${proposalId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (res.ok) {
        await fetchProposals();
      } else {
        alert('Failed to update swap proposal status.');
      }
    } catch (err) {
      console.error('Error updating proposal status:', err);
    } finally {
      setLoadingId(null);
    }
  };

  // ==========================================
  // 1. SYSTEM ADMIN: GLOBAL AUDIT MONITOR VIEW
  // ==========================================
  if (isAdmin) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-10 space-y-6 min-h-[calc(100vh-160px)]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-purple-100 text-purple-700 text-xs font-black px-2.5 py-1 rounded-lg uppercase">
                Admin Panel
              </span>
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                Live Swaps Monitor & Global Audit
              </h1>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-1">
              Real-time audit log of all peer-to-peer handshakes across the platform.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="bg-slate-100 text-slate-700 text-xs font-extrabold px-3 py-2 rounded-xl border border-slate-200">
              Total Swaps: <strong>{proposals.length}</strong>
            </span>
            <button
              onClick={() => fetchProposals()}
              className="bg-[#4f46e5] hover:bg-[#4338ca] text-white text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer shadow-xs"
            >
              🔄 Refresh Feed
            </button>
          </div>
        </div>

        {proposals.length === 0 ? (
          <div className="bg-white border border-slate-200/80 rounded-3xl p-16 text-center shadow-xs space-y-3">
            <span className="text-4xl">📊</span>
            <h3 className="text-base font-extrabold text-slate-800">No Swap Proposals Transmitted Yet</h3>
            <p className="text-xs text-slate-500">When users initiate skill exchanges, they will be audited here.</p>
          </div>
        ) : (
          <div className="bg-white border border-slate-200/80 rounded-3xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200/80 text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">
                    <th className="py-4 px-6">Exchange Skill</th>
                    <th className="py-4 px-6">Requester</th>
                    <th className="py-4 px-6">Target Provider</th>
                    <th className="py-4 px-6 text-center">Synergy Match</th>
                    <th className="py-4 px-6 text-center">Status</th>
                    <th className="py-4 px-6 text-right">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs font-semibold text-slate-700">
                  {proposals.map((p) => {
                    const requesterName = typeof p.requester === 'object' ? p.requester?.name : 'Durga';
                    const requesterEmail = typeof p.requester === 'object' ? p.requester?.email : '';
                    
                    const providerName = typeof p.targetProvider === 'object' ? p.targetProvider?.name : p.targetSkill?.providerName || 'Leela';
                    const providerEmail = typeof p.targetProvider === 'object' ? p.targetProvider?.email : '';

                    const skillTitle = p.targetSkill?.title || 'Skill Offer';

                    return (
                      <tr key={p._id} className="hover:bg-slate-50/80 transition">
                        <td className="py-4 px-6">
                          <span className="font-extrabold text-slate-900 block">{skillTitle}</span>
                          <span className="text-[10px] text-slate-400 font-medium">ID: {p._id.slice(-6)}</span>
                        </td>
                        <td className="py-4 px-6">
                          <span className="font-bold text-slate-900 block">{requesterName}</span>
                          <span className="text-[11px] text-slate-400 font-normal">{requesterEmail}</span>
                        </td>
                        <td className="py-4 px-6">
                          <span className="font-bold text-slate-900 block">{providerName}</span>
                          <span className="text-[11px] text-slate-400 font-normal">{providerEmail}</span>
                        </td>
                        <td className="py-4 px-6 text-center">
                          <span className="inline-block bg-indigo-50 text-[#4f46e5] text-[11px] font-black px-2.5 py-1 rounded-lg">
                            {p.synergyScore || 50}%
                          </span>
                        </td>
                        <td className="py-4 px-6 text-center">
                          <span
                            className={`inline-block px-3 py-1 rounded-lg text-[11px] font-extrabold ${
                              p.status === 'Accepted'
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                : p.status === 'Cancelled'
                                ? 'bg-red-100 text-red-700 border border-red-200'
                                : p.status === 'Declined'
                                ? 'bg-slate-100 text-slate-700 border border-slate-200'
                                : 'bg-amber-100 text-amber-800 border border-amber-200'
                            }`}
                          >
                            {p.status === 'Cancelled' ? '🚫 Post Removed' : p.status === 'Transmitted' ? '⏳ Pending' : p.status}
                          </span>
                        </td>
                        <td className="py-4 px-6 text-right text-slate-400 font-normal text-[11px]">
                          {p.createdAt ? new Date(p.createdAt).toLocaleDateString() : 'Active'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================
  // 2. REGULAR USER: INBOUND & OUTBOUND TABS
  // ==========================================
  const currentList = activeTab === 'inbound' ? inboundProposals : outboundProposals;

  return (
    <div className="max-w-6xl mx-auto px-6 py-12 space-y-8 min-h-[calc(100vh-160px)]">
      
      {/* HEADER & TAB CONTROLS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">My Skill Swaps</h1>
          <p className="text-xs text-slate-500 font-medium mt-1">
            Manage incoming peer handshakes and accepted sessions.
          </p>
        </div>

        {/* TABS SWITCHER */}
        <div className="flex bg-slate-100 p-1.5 rounded-2xl border border-slate-200/80 text-xs font-extrabold text-slate-600">
          <button
            onClick={() => setActiveTab('inbound')}
            className={`px-5 py-2.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'inbound'
                ? 'bg-white text-[#4f46e5] shadow-xs font-black'
                : 'hover:text-slate-900'
            }`}
          >
            Inbound Requests ({inboundProposals.length})
          </button>
          
          <button
            onClick={() => setActiveTab('outbound')}
            className={`px-5 py-2.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'outbound'
                ? 'bg-white text-[#4f46e5] shadow-xs font-black border border-slate-200'
                : 'hover:text-slate-900'
            }`}
          >
            Outbound Requests ({outboundProposals.length})
          </button>
        </div>
      </div>

      {/* PROPOSALS LIST */}
      {currentList.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-3xl p-12 text-center shadow-xs space-y-3">
          <span className="text-4xl">🤝</span>
          <h3 className="text-base font-extrabold text-slate-800">
            No {activeTab === 'inbound' ? 'Incoming' : 'Sent'} Swaps Found
          </h3>
          <p className="text-xs text-slate-500">
            {activeTab === 'inbound'
              ? 'When other peer learners request a swap with you, they will appear here.'
              : 'Browse the Explore Hub catalog to initiate your first skill exchange.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {currentList.map((proposal) => {
            const isOutbound = activeTab === 'outbound';

            const targetUser = isOutbound ? proposal.targetProvider : proposal.requester;
            const targetUserName =
              typeof targetUser === 'object'
                ? targetUser?.name
                : proposal.targetSkill?.providerName || 'Peer Learner';

            const targetUserEmail =
              typeof targetUser === 'object' ? targetUser?.email : '';

            const skillTitle = proposal.targetSkill?.title || 'Skill Exchange';

            const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(
              `SkillSwap Session: ${skillTitle}`
            )}&add=${encodeURIComponent(targetUserEmail)}`;

            return (
              <div
                key={proposal._id}
                className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs flex flex-col justify-between space-y-4"
              >
                <div>
                  {/* TOP BADGES */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="bg-indigo-50 text-[#4f46e5] text-[10px] font-black uppercase px-2.5 py-1 rounded-lg tracking-wider">
                      SYNERGY MATCH: {proposal.synergyScore || 50}%
                    </span>

                    <span
                      className={`px-3 py-1 rounded-lg text-xs font-black ${
                        proposal.status === 'Accepted'
                          ? 'bg-emerald-100 text-emerald-800'
                          : proposal.status === 'Cancelled'
                          ? 'bg-red-100 text-red-700'
                          : proposal.status === 'Declined'
                          ? 'bg-slate-100 text-slate-700'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {proposal.status === 'Cancelled'
                        ? 'Skill Removed'
                        : proposal.status === 'Transmitted'
                        ? 'Pending'
                        : proposal.status}
                    </span>
                  </div>

                  {/* SKILL TITLE & MENTOR */}
                  <h3 className="text-lg font-black text-slate-900 tracking-tight">
                    {skillTitle}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    {isOutbound ? 'Target Mentor' : 'Requested By'}:{' '}
                    <strong className="text-slate-700">{targetUserName}</strong>
                  </p>

                  {/* ⚡ 1. CANCELLED / POST REMOVED BY ADMIN BANNER */}
                  {proposal.status === 'Cancelled' && (
                    <div className="mt-4 p-4 bg-red-50/90 border border-red-200/90 rounded-2xl space-y-2.5">
                      <div className="flex items-center gap-2 text-red-800 font-extrabold text-xs">
                        <span>⚠️</span>
                        <span>Skill Post Removed by Admin</span>
                      </div>

                      <p className="text-xs text-red-900 font-medium leading-relaxed">
                        This skill post is no longer available on the platform.
                      </p>

                      {proposal.cancellationReason && (
                        <div className="bg-white/90 border border-red-200 p-2.5 rounded-xl text-xs text-red-800 space-y-0.5">
                          <span className="block text-[10px] uppercase font-bold text-red-500 tracking-wider">
                            Admin Removal Reason
                          </span>
                          <p className="font-semibold text-red-900">{proposal.cancellationReason}</p>
                        </div>
                      )}

                      <p className="text-[11px] text-red-700 font-medium flex items-center gap-1.5 pt-0.5">
                        <span>📩</span>
                        <span>Full cancellation details have been sent to your email.</span>
                      </p>
                    </div>
                  )}

                  {/* ⚡ 2. ACCEPTED SWAP BANNER */}
                  {proposal.status === 'Accepted' && (
                    <div className="mt-4 p-4 bg-emerald-50/80 border border-emerald-200/80 rounded-2xl space-y-3">
                      <div className="flex items-center gap-2 text-emerald-800 font-extrabold text-xs">
                        <span>🎉</span>
                        <span>{isOutbound ? 'Handshake Accepted by Mentor!' : 'You Accepted This Swap Request!'}</span>
                      </div>

                      <p className="text-xs text-emerald-900 font-medium leading-relaxed">
                        {isOutbound ? (
                          <>
                            <strong>{targetUserName}</strong> has accepted your handshake. Reach out at{' '}
                            <strong className="underline">{targetUserEmail}</strong> to schedule your session.
                          </>
                        ) : (
                          <>
                            You confirmed this exchange with <strong>{targetUserName}</strong>. Contact them at{' '}
                            <strong className="underline">{targetUserEmail}</strong> to get started.
                          </>
                        )}
                      </p>

                      {/* QUICK SCHEDULING BUTTONS */}
                      <div className="flex flex-col sm:flex-row gap-2 pt-1">
                        <a
                          href="https://meet.google.com/new"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2.5 px-3 rounded-xl text-center transition shadow-xs flex items-center justify-center gap-1.5"
                        >
                          <span>📹</span>
                          <span>Start Google Meet</span>
                        </a>

                        <a
                          href={googleCalendarUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex-1 bg-white hover:bg-slate-50 text-emerald-800 border border-emerald-300 text-xs font-bold py-2.5 px-3 rounded-xl text-center transition flex items-center justify-center gap-1.5"
                        >
                          <span>📅</span>
                          <span>Schedule Calendar Event</span>
                        </a>
                      </div>
                    </div>
                  )}
                </div>

                {/* INBOUND ACTION BUTTONS (Only for active Pending requests) */}
                {!isOutbound && proposal.status === 'Transmitted' && (
                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => handleStatusUpdate(proposal._id, 'Accepted')}
                      disabled={loadingId === proposal._id}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold py-2.5 rounded-xl transition cursor-pointer shadow-xs disabled:opacity-50"
                    >
                      ✓ Accept
                    </button>

                    <button
                      onClick={() => handleStatusUpdate(proposal._id, 'Declined')}
                      disabled={loadingId === proposal._id}
                      className="flex-1 bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 border border-slate-200 text-xs font-extrabold py-2.5 rounded-xl transition cursor-pointer disabled:opacity-50"
                    >
                      ✕ Decline
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default MySwaps;