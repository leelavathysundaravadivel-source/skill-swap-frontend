import React from 'react';
import { Link } from 'react-router-dom';

const Landing = () => {
  return (
    <div className="min-h-[calc(100vh-140px)] flex flex-col justify-center items-center text-center px-4 py-12 max-w-4xl mx-auto space-y-8">
      <h1 className="text-5xl sm:text-7xl font-black text-slate-900 tracking-tight leading-none">
        Learn, Collaborate, <br className="hidden sm:inline" />
        <span className="inline-block bg-indigo-50 text-indigo-600 px-6 py-1 rounded-2xl mt-2">
          Grow
        </span>
      </h1>

      <p className="text-slate-600 text-sm sm:text-base max-w-2xl leading-relaxed">
        Connect with peers who share your learning goals. Exchange skills, collaborate on
        real-world projects, and build your career — all in one community.
      </p>

      <div className="pt-2">
        <Link
          to="/signup"
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm px-8 py-3.5 rounded-full shadow-lg shadow-indigo-500/25 transition cursor-pointer inline-block"
        >
          Join SkillSwap →
        </Link>
      </div>

      <p className="text-xs text-slate-500 font-medium">
        Already on SkillSwap?{' '}
        <Link to="/login" className="text-indigo-600 font-bold hover:underline">
          Log In
        </Link>
      </p>
    </div>
  );
};

export default Landing;